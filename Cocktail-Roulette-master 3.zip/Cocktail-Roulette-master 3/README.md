# Cocktail-Roulette
API Project
Group Project 1

Api search link
* [Api search link](https://santosedgar5565.github.io/drinksProjectTest1/?).


# The Cocktail Roulette App

 ### An app to help you find cool new recipes for cocktails you can try with your friends!

### In our App you can : 

#### - Learn how to make new cocktails with a list ingredients & a how-to video. 

#### - Search for your nearest liquor store to grab the materials you need to make an awesome cocktail. 

#### - Or if you rather take the recipe to the bar; Search a cocktail bar in your area & show the bartender the recipe!

------------------------------------------------------------

##### APIs we source from are :
##### - Absoulte Drinks Database :
###### From within the Absolute Drink Database we used their library of cocktails, lists of ingredients, as well as their how-to-make video's for each cocktail.
##### - Google Maps


##### We also utilized : 

##### - JavaScript
##### - jQuery
##### - AJAX
##### - Materialize CSS Library
##### - Google Fonts
##### - 
##### -
##### -




