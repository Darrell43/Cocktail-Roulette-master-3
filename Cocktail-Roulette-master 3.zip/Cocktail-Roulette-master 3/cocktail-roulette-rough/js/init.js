(function($){
  $(function(){

    $('.button-collapse').sideNav();
    $('.parallax').parallax();

      $(document).ready(function(){
    $('.modal').modal();
  });
  }); // end of document ready
})(jQuery); // end of jQuery name space
